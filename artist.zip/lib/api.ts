export const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_BASE_URL || "https://api.sedabox.com/api"
).replace(/\/$/, "");

export class ApiError extends Error {
  status: number;
  details: unknown;

  constructor(message: string, status = 0, details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

type ApiOptions = Omit<RequestInit, "body"> & {
  body?: BodyInit | Record<string, unknown> | null;
  query?: Record<string, string | number | boolean | null | undefined>;
  auth?: boolean;
  retryAuth?: boolean;
};

const isObject = (value: unknown): value is Record<string, unknown> =>
  Boolean(value) && typeof value === "object" && !Array.isArray(value);

const collectMessages = (value: unknown, path = ""): string[] => {
  if (typeof value === "string") return [path ? `${path}: ${value}` : value];
  if (Array.isArray(value)) return value.flatMap((item) => collectMessages(item, path));
  if (isObject(value)) {
    return Object.entries(value).flatMap(([key, item]) =>
      collectMessages(item, ["detail", "error", "message", "non_field_errors"].includes(key) ? path : key),
    );
  }
  return [];
};

export const getApiErrorMessage = (
  error: unknown,
  fallback = "Something went wrong. Please try again.",
): string => {
  if (error instanceof ApiError || error instanceof Error) return error.message || fallback;
  return fallback;
};

const parseResponse = async (response: Response): Promise<unknown> => {
  if (response.status === 204) return null;
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) return response.json().catch(() => ({}));
  return response.text().catch(() => "");
};

let refreshPromise: Promise<boolean> | null = null;

const refreshAccessToken = async (): Promise<boolean> => {
  if (typeof window === "undefined") return false;
  if (refreshPromise) return refreshPromise;

  refreshPromise = (async () => {
    const refreshToken = localStorage.getItem("sedabox_refresh_token");
    if (!refreshToken) return false;
    try {
      const response = await fetch(`${API_BASE_URL}/auth/token/refresh/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken }),
      });
      const data = (await parseResponse(response)) as Record<string, unknown>;
      if (!response.ok || !data?.accessToken) return false;
      localStorage.setItem("sedabox_token", String(data.accessToken));
      if (data.refreshToken) localStorage.setItem("sedabox_refresh_token", String(data.refreshToken));
      return true;
    } catch {
      return false;
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise;
};

export async function apiRequest<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
  const {
    query,
    auth = true,
    retryAuth = true,
    body,
    headers: suppliedHeaders,
    ...requestOptions
  } = options;
  const url = new URL(endpoint.startsWith("http") ? endpoint : `${API_BASE_URL}${endpoint.startsWith("/") ? endpoint : `/${endpoint}`}`);
  Object.entries(query || {}).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") url.searchParams.set(key, String(value));
  });

  const headers = new Headers(suppliedHeaders);
  let requestBody: BodyInit | undefined;
  const isFormData = typeof FormData !== "undefined" && body instanceof FormData;
  const isBlob = typeof Blob !== "undefined" && body instanceof Blob;
  const isSearchParams = typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams;
  if (isFormData || typeof body === "string" || isBlob || isSearchParams) {
    requestBody = body as BodyInit;
  } else if (body !== undefined && body !== null) {
    headers.set("Content-Type", "application/json");
    requestBody = JSON.stringify(body);
  }
  if (auth && typeof window !== "undefined") {
    const token = localStorage.getItem("sedabox_token");
    if (token) headers.set("Authorization", `Bearer ${token}`);
  }

  let response: Response;
  try {
    response = await fetch(url.toString(), { ...requestOptions, headers, body: requestBody, cache: "no-store" });
  } catch (error) {
    if ((error as Error)?.name === "AbortError") throw error;
    throw new ApiError("Could not connect to the server. Check your internet connection and try again.");
  }

  if (response.status === 401 && auth && retryAuth && (await refreshAccessToken())) {
    return apiRequest<T>(endpoint, { ...options, retryAuth: false });
  }

  const data = await parseResponse(response);
  if (!response.ok) {
    const messages = collectMessages(data);
    const defaultMessage = response.status === 401
      ? "Your session has expired. Please sign in again."
      : response.status === 403
        ? "You do not have permission to perform this action."
        : response.status >= 500
          ? "The server could not complete this request. Please try again."
          : "The request could not be completed.";
    throw new ApiError(messages.filter(Boolean).join(" · ") || defaultMessage, response.status, data);
  }
  return data as T;
}

export interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export const unwrapList = <T>(value: T[] | { results?: T[] } | null | undefined): T[] =>
  Array.isArray(value) ? value : value?.results || [];

export async function fetchAllPages<T>(endpoint: string, query?: ApiOptions["query"]): Promise<T[]> {
  const first = await apiRequest<T[] | PaginatedResponse<T>>(endpoint, { query });
  if (Array.isArray(first)) return first;
  const items = [...(first.results || [])];
  let next = first.next;
  while (next) {
    const page = await apiRequest<PaginatedResponse<T>>(next);
    items.push(...(page.results || []));
    next = page.next;
  }
  return items;
}
