import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  CheckCircle2,
  ChevronLeft,
  ClipboardCopy,
  CopyPlus,
  CloudUpload,
  Disc3,
  FileAudio,
  FileSpreadsheet,
  ImagePlus,
  Info,
  Library,
  Loader2,
  Music2,
  Plus,
  RefreshCw,
  Save,
  Search,
  Send,
  Settings2,
  Trash2,
  UploadCloud,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { apiRequest, getApiErrorMessage, unwrapList } from "../lib/api";
import { useNavigation } from "../contexts/NavigationContext";
import { useToast } from "../contexts/ToastContext";
import SongModal from "./SongModal";
import { ArtistOption, PartialSong, SongMetadata, TaxonomyOption } from "./types";
import {
  ArtistRelease,
  ReleaseContributor,
  ReleaseTrackApi,
  ReleaseTrackExtras,
  ReleaseType,
  SharedMetadata,
} from "./releaseTypes";

interface ReleaseComposerProps { releaseId: string; }
interface RecordingsResponse { results?: ReleaseTrackApi[]; }
interface UploadResponse { message: string; song: ReleaseTrackApi; }

const inputClass = "w-full rounded-xl border border-[#343434] bg-[#1a1a1a] px-3.5 py-3 text-white outline-none transition placeholder:text-[#5f5f5f] focus:border-[#1DB954] focus:ring-2 focus:ring-[#1DB954]/10";
const labelClass = "mb-2 block text-xs font-black text-[#d7d7d7]";
const stepNames = ["اطلاعات انتشار", "ترک‌لیست", "متادیتای ترک‌ها", "اطلاعات مشترک", "متادیتای انتشار", "بازبینی و ارسال"];
const releaseTypeOptions: Array<{ value: ReleaseType; title: string; description: string }> = [
  { value: "single", title: "Single", description: "یک ترک مستقل" },
  { value: "ep", title: "EP", description: "مجموعه کوتاه" },
  { value: "album", title: "Album", description: "انتشار چندترکی" },
  { value: "compilation", title: "Compilation", description: "مجموعه یا گردآوری" },
];
const releaseStatusLabels: Record<ArtistRelease["status"], string> = {
  draft: "پیش‌نویس",
  in_review: "در حال بررسی",
  changes_requested: "نیازمند اصلاح",
  approved: "تأییدشده",
  scheduled: "زمان‌بندی‌شده",
  live: "منتشرشده",
  rejected: "ردشده",
  taken_down: "حذف‌شده",
};

const listText = (value?: string[]) => (value || []).join(", ");
const textList = (value: string) => value.split(/[,،\n]/).map((item) => item.trim()).filter(Boolean);
const ids = (items?: Array<TaxonomyOption | number>) => (items || []).map((item) => typeof item === "number" ? item : Number(item.id)).filter(Boolean);
const humanBytes = (value: number) => value > 1024 ** 2 ? `${(value / 1024 ** 2).toFixed(1)} MB` : `${Math.ceil(value / 1024)} KB`;
const titleFromFilename = (name: string) => name.replace(/\.[^.]+$/, "").replace(/^\s*\d+[\s._-]+/, "").replace(/[_-]+/g, " ").trim() || "Untitled Track";

const readImageDimensions = (file: File): Promise<{ width: number; height: number }> => new Promise((resolve, reject) => {
  const url = URL.createObjectURL(file);
  const image = new Image();
  const cleanup = () => URL.revokeObjectURL(url);
  image.onload = () => {
    const dimensions = { width: image.naturalWidth, height: image.naturalHeight };
    cleanup();
    resolve(dimensions);
  };
  image.onerror = () => {
    cleanup();
    reject(new Error("Artwork is damaged or cannot be read."));
  };
  image.src = url;
});

const parseDelimitedText = (input: string): string[][] => {
  const text = input.replace(/^\uFEFF/, "");
  const firstLine = text.split(/\r?\n/, 1)[0] || "";
  const delimiter = firstLine.includes("\t") ? "\t" : ",";
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char === '"') {
      if (quoted && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
      continue;
    }
    if (!quoted && char === delimiter) {
      row.push(cell.trim());
      cell = "";
      continue;
    }
    if (!quoted && (char === "\n" || char === "\r")) {
      if (char === "\r" && text[index + 1] === "\n") index += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  if (quoted) throw new Error("The metadata file contains an unclosed quoted cell.");
  return rows;
};

const compactMetadata = (metadata: SharedMetadata): Record<string, unknown> =>
  Object.fromEntries(Object.entries(metadata).filter(([, value]) =>
    Array.isArray(value) ? value.length > 0 : String(value ?? "").trim().length > 0,
  ));

const mapTrackToSong = (track: ReleaseTrackApi): SongMetadata => {
  const featured = track.featured_artists || [];
  const status = track.status || "draft";
  return {
    id: track.id,
    title: track.title || "",
    title_en: track.title_en || "",
    artist: track.artist_name || "",
    featuredArtists: featured,
    featured_artists: featured,
    featured_artist_ids: featured.map((item) => item.id),
    album: track.album_title || "",
    duration: track.duration_display || "0:00",
    plays: "0",
    status,
    approvalStatus: status === "published" || status === "approved" ? "approved" : status === "rejected" ? "rejected" : status === "pending" ? "pending" : "none",
    image: track.cover_image || "",
    audioFile: track.audio_file || track.stream_url,
    releaseDate: track.release_date || "",
    release_date: track.release_date || "",
    genre: (track.genre_ids || []).map((item) => item.title),
    subGenre: (track.sub_genre_ids || []).map((item) => item.title),
    mood: (track.mood_ids || []).map((item) => item.title),
    tags: (track.tag_ids || []).map((item) => item.title),
    genre_ids: ids(track.genre_ids),
    sub_genre_ids: ids(track.sub_genre_ids),
    mood_ids: ids(track.mood_ids),
    tag_ids: ids(track.tag_ids),
    language: track.language || "fa",
    tempo: track.tempo ?? 120,
    energy: track.energy ?? 50,
    danceability: track.danceability ?? 50,
    valence: track.valence ?? 50,
    acousticness: track.acousticness ?? 0,
    instrumentalness: track.instrumentalness ?? 0,
    liveness: Boolean(track.live_performed),
    live_performed: Boolean(track.live_performed),
    speechiness: track.speechiness ?? 0,
    label: track.label || "",
    label_en: track.label_en || "",
    producers: track.producers || [],
    producers_en: track.producers_en || [],
    composers: track.composers || [],
    composers_en: track.composers_en || [],
    lyricists: track.lyricists || [],
    lyricists_en: track.lyricists_en || [],
    lyrics: track.lyrics || "",
    lyrics_en: track.lyrics_en || "",
    description: track.description || "",
    description_en: track.description_en || "",
    credits: track.credits || "",
    credits_en: track.credits_en || "",
    is_single: false,
  };
};

const editablePayload = (release: ArtistRelease) => ({
  title: release.title,
  title_en: release.title_en || "",
  release_type: release.release_type,
  previously_released: Boolean(release.previously_released),
  current_step: release.current_step,
  shared_metadata: release.shared_metadata,
  release_metadata: release.release_metadata,
  track_extras: release.track_extras,
  lock_version: release.lock_version,
});

const editableSnapshot = (release: ArtistRelease) => {
  const { lock_version: _lockVersion, ...payload } = editablePayload(release);
  return JSON.stringify(payload);
};

const ReleaseComposer: React.FC<ReleaseComposerProps> = ({ releaseId }) => {
  const { navigateTo } = useNavigation();
  const { showToast } = useToast();
  const [release, setRelease] = useState<ArtistRelease | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string>("");
  const [taxonomies, setTaxonomies] = useState<{ genres: TaxonomyOption[]; subgenres: TaxonomyOption[]; moods: TaxonomyOption[]; tags: TaxonomyOption[] }>({ genres: [], subgenres: [], moods: [], tags: [] });
  const [recordings, setRecordings] = useState<ReleaseTrackApi[]>([]);
  const [recordingsLoading, setRecordingsLoading] = useState(false);
  const [contributors, setContributors] = useState<ReleaseContributor[]>([]);
  const [releaseArtistQuery, setReleaseArtistQuery] = useState("");
  const [releaseArtistResults, setReleaseArtistResults] = useState<ArtistOption[]>([]);
  const [searchingReleaseArtists, setSearchingReleaseArtists] = useState(false);
  const [artistDirectory, setArtistDirectory] = useState<Record<number, ArtistOption>>({});
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Array<{ id: string; name: string; state: "queued" | "uploading" | "done" | "error"; message?: string }>>([]);
  const [existingOpen, setExistingOpen] = useState(false);
  const [recordingQuery, setRecordingQuery] = useState("");
  const [selectedExisting, setSelectedExisting] = useState<number[]>([]);
  const [selectedTracks, setSelectedTracks] = useState<number[]>([]);
  const [editingTrack, setEditingTrack] = useState<ReleaseTrackApi | null>(null);
  const [editingSong, setEditingSong] = useState(false);
  const [extrasTrackId, setExtrasTrackId] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [cloning, setCloning] = useState(false);
  const [copySource, setCopySource] = useState<number | "">("");
  const [newContributor, setNewContributor] = useState({ name: "", name_en: "", role: "producer" });
  const lastSnapshot = useRef("");
  const initialized = useRef(false);
  const releaseRef = useRef<ArtistRelease | null>(null);
  const saveQueueRef = useRef<Promise<ArtistRelease | null>>(Promise.resolve(null));
  const artworkRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLInputElement>(null);
  const csvRef = useRef<HTMLInputElement>(null);

  const replaceRelease = useCallback((next: ArtistRelease, updateSnapshot = true) => {
    releaseRef.current = next;
    setRelease(next);
    if (updateSnapshot) lastSnapshot.current = editableSnapshot(next);
  }, []);

  const mutateRelease = useCallback((updater: (current: ArtistRelease) => ArtistRelease) => {
    const current = releaseRef.current;
    if (!current) return;
    const next = updater(current);
    releaseRef.current = next;
    setRelease(next);
  }, []);

  const loadRelease = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    try {
      const data = await apiRequest<ArtistRelease>(`/artist/releases/${releaseId}/`);
      replaceRelease(data);
      setArtistDirectory((current) => {
        const next = { ...current };
        [...(data.release_artists || []), ...(data.primary_artist ? [data.primary_artist] : [])].forEach((item) => {
          if (item?.id) next[item.id] = item;
        });
        return next;
      });
      initialized.current = true;
      setSelectedTracks((current) => current.filter((id) => data.track_ids.includes(id)));
      setExtrasTrackId((current) => current ?? data.track_ids[0] ?? null);
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not load the release draft."), "error");
    } finally {
      setLoading(false);
    }
  }, [releaseId, replaceRelease, showToast]);

  const loadRecordings = useCallback(async (query = "", quiet = false) => {
    if (!quiet) setRecordingsLoading(true);
    try {
      const data = await apiRequest<ReleaseTrackApi[] | RecordingsResponse>("/artist/songs/", { query: { q: query.trim() } });
      setRecordings(unwrapList(data));
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not load recordings."), "error");
    } finally {
      if (!quiet) setRecordingsLoading(false);
    }
  }, [showToast]);

  useEffect(() => { releaseRef.current = release; }, [release]);

  useEffect(() => {
    let cancelled = false;
    void Promise.allSettled([
      loadRelease(),
      Promise.all([
        apiRequest<TaxonomyOption[] | { results: TaxonomyOption[] }>("/genres/"),
        apiRequest<TaxonomyOption[] | { results: TaxonomyOption[] }>("/subgenres/"),
        apiRequest<TaxonomyOption[] | { results: TaxonomyOption[] }>("/moods/"),
        apiRequest<TaxonomyOption[] | { results: TaxonomyOption[] }>("/tags/"),
      ]).then(([genres, subgenres, moods, tags]) => {
        if (!cancelled) setTaxonomies({ genres: unwrapList(genres), subgenres: unwrapList(subgenres), moods: unwrapList(moods), tags: unwrapList(tags) });
      }),
      loadRecordings("", true),
      apiRequest<{ results: ReleaseContributor[] }>("/artist/contributors/").then((data) => { if (!cancelled) setContributors(data.results || []); }),
    ]).then((results) => results.forEach((result, index) => {
      if (result.status === "rejected" && index > 0) showToast(getApiErrorMessage(result.reason, "Some composer data could not be loaded."), "error");
    }));
    return () => { cancelled = true; };
  }, [loadRecordings, loadRelease, showToast]);

  useEffect(() => {
    if (!existingOpen) return;
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setRecordingsLoading(true);
      try {
        const data = await apiRequest<ReleaseTrackApi[] | RecordingsResponse>("/artist/songs/", {
          query: { q: recordingQuery.trim() },
          signal: controller.signal,
        });
        setRecordings(unwrapList(data));
      } catch (error) {
        if ((error as Error)?.name !== "AbortError") showToast(getApiErrorMessage(error, "Could not search recordings."), "error");
      } finally {
        if (!controller.signal.aborted) setRecordingsLoading(false);
      }
    }, recordingQuery.trim() ? 300 : 0);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [existingOpen, recordingQuery, showToast]);

  useEffect(() => {
    const query = releaseArtistQuery.trim();
    if (query.length < 2) {
      setReleaseArtistResults([]);
      setSearchingReleaseArtists(false);
      return;
    }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setSearchingReleaseArtists(true);
      try {
        const results = await apiRequest<ArtistOption[]>("/artists/", {
          query: { q: query },
          signal: controller.signal,
        });
        const selected = new Set(release?.release_metadata.release_artist_ids || []);
        const available = (Array.isArray(results) ? results : []).filter((item) => !selected.has(item.id));
        setReleaseArtistResults(available);
        setArtistDirectory((current) => {
          const next = { ...current };
          results.forEach((item) => { if (item?.id) next[item.id] = item; });
          return next;
        });
      } catch (error) {
        if ((error as Error)?.name !== "AbortError") {
          showToast(getApiErrorMessage(error, "Could not search release artists."), "error");
        }
      } finally {
        if (!controller.signal.aborted) setSearchingReleaseArtists(false);
      }
    }, 300);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [release?.release_metadata.release_artist_ids, releaseArtistQuery, showToast]);

  const persistLatestDraft = useCallback((notifyOnError = true): Promise<ArtistRelease | null> => {
    const queued = saveQueueRef.current.catch(() => null).then(async () => {
      const draft = releaseRef.current;
      if (!draft || !initialized.current || draft.status !== "draft") return draft;
      const payload = editablePayload(draft);
      const sentSnapshot = editableSnapshot(draft);
      if (sentSnapshot === lastSnapshot.current) return draft;
      setSaving(true);
      try {
        const updated = await apiRequest<ArtistRelease>(`/artist/releases/${draft.id}/`, { method: "PATCH", body: payload });
        const updatedSnapshot = editableSnapshot(updated);
        const current = releaseRef.current;
        const currentSnapshot = current ? editableSnapshot(current) : sentSnapshot;
        const next = current && currentSnapshot !== sentSnapshot
          ? { ...current, lock_version: updated.lock_version, updated_at: updated.updated_at }
          : updated;
        lastSnapshot.current = current && currentSnapshot !== sentSnapshot ? sentSnapshot : updatedSnapshot;
        releaseRef.current = next;
        setRelease(next);
        setSavedAt(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }));
        return next;
      } catch (error) {
        if (notifyOnError) showToast(getApiErrorMessage(error, "Auto-save failed. Your unsaved changes are still on this screen."), "error");
        throw error;
      } finally {
        setSaving(false);
      }
    });
    saveQueueRef.current = queued.catch(() => null);
    return queued;
  }, [showToast]);

  useEffect(() => {
    if (!release || !initialized.current || release.status !== "draft") return;
    const snapshot = editableSnapshot(release);
    if (snapshot === lastSnapshot.current) return;
    const timer = window.setTimeout(() => { void persistLatestDraft().catch(() => undefined); }, 700);
    return () => window.clearTimeout(timer);
  }, [persistLatestDraft, release]);

  useEffect(() => () => {
    const draft = releaseRef.current;
    if (draft?.status === "draft" && editableSnapshot(draft) !== lastSnapshot.current) {
      void persistLatestDraft(false).catch(() => undefined);
    }
  }, [persistLatestDraft]);

  const updateRelease = <K extends keyof ArtistRelease>(key: K, value: ArtistRelease[K]) => mutateRelease((current) => ({ ...current, [key]: value }));
  const updateMetadata = (patch: Partial<ArtistRelease["release_metadata"]>) => mutateRelease((current) => ({ ...current, release_metadata: { ...current.release_metadata, ...patch } }));
  const updateShared = (patch: Partial<SharedMetadata>) => mutateRelease((current) => ({ ...current, shared_metadata: { ...current.shared_metadata, ...patch } }));
  const currentStep = release?.current_step || 1;
  const readOnly = release?.status !== "draft";
  const todayIso = useMemo(() => {
    const today = new Date();
    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
    return today.toISOString().slice(0, 10);
  }, []);

  const goStep = (step: number) => {
    if (!release) return;
    updateRelease("current_step", Math.max(1, Math.min(6, step)));
    window.requestAnimationFrame(() => document.getElementById("release-composer-top")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  };

  const prepareServerMutation = async () => {
    try {
      await persistLatestDraft(false);
      return true;
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not save the latest release changes. Try again."), "error");
      return false;
    }
  };

  const leaveComposer = async () => {
    if (release?.status === "draft" && !(await prepareServerMutation())) return;
    navigateTo("releases");
  };

  const refreshComposer = async () => {
    if (release?.status === "draft" && !(await prepareServerMutation())) return;
    await loadRelease(true);
  };

  const uploadFiles = async (files: File[]) => {
    if (!release || !files.length || readOnly) return;
    if (uploading) return showToast("Wait for the current upload queue to finish.", "error");
    const accepted = files.filter((file) => {
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (!ext || !["mp3", "wav"].includes(ext)) {
        showToast(`${file.name}: only MP3 and WAV files are supported.`, "error");
        return false;
      }
      if (!file.size) {
        showToast(`${file.name}: the selected file is empty.`, "error");
        return false;
      }
      if (file.size > 500 * 1024 * 1024) {
        showToast(`${file.name}: file must be smaller than 500MB.`, "error");
        return false;
      }
      return true;
    });
    if (!accepted.length || !(await prepareServerMutation())) return;
    setUploading(true);
    setUploadProgress(accepted.map((file, index) => ({ id: `${index}-${file.name}-${file.size}-${file.lastModified}`, name: file.name, state: "queued" })));
    const uploadedIds: number[] = [];
    try {
      for (let index = 0; index < accepted.length; index += 1) {
        const file = accepted[index];
        setUploadProgress((current) => current.map((item, position) => position === index ? { ...item, state: "uploading", message: undefined } : item));
        try {
          const form = new FormData();
          form.set("title", titleFromFilename(file.name));
          form.set("title_en", "");
          form.set("language", "fa");
          form.set("is_single", "false");
          form.set("save_as_draft", "true");
          form.set("audio_file", file);
          const response = await apiRequest<UploadResponse>("/artist/songs/", { method: "POST", body: form });
          uploadedIds.push(response.song.id);
          setUploadProgress((current) => current.map((item, position) => position === index ? { ...item, state: "done" } : item));
        } catch (error) {
          setUploadProgress((current) => current.map((item, position) => position === index ? { ...item, state: "error", message: getApiErrorMessage(error, "Upload failed.") } : item));
        }
      }

      if (!uploadedIds.length) return showToast("No tracks were uploaded. Review the errors and try again.", "error");
      try {
        const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/tracks/`, { method: "POST", body: { action: "add", song_ids: uploadedIds, lock_version: releaseRef.current?.lock_version } });
        replaceRelease(updated);
        showToast(`${uploadedIds.length} track${uploadedIds.length === 1 ? "" : "s"} uploaded and added to the release.`, "success");
      } catch (error) {
        showToast(getApiErrorMessage(error, "Tracks were uploaded to Recordings, but could not be attached to this release."), "error");
        return;
      }

      await loadRecordings("", true);
    } finally {
      setUploading(false);
      if (audioRef.current) audioRef.current.value = "";
    }
  };

  const addExisting = async () => {
    if (!release || !selectedExisting.length || !(await prepareServerMutation())) return;
    setSubmitting(true);
    try {
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/tracks/`, { method: "POST", body: { action: "add", song_ids: selectedExisting, lock_version: releaseRef.current?.lock_version } });
      replaceRelease(updated);
      setExistingOpen(false);
      setSelectedExisting([]);
      showToast("Selected recordings were added without changing any live release.", "success");
      await loadRecordings("", true);
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not add the selected recordings."), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const removeTrack = async (trackId: number) => {
    if (!release || readOnly || !(await prepareServerMutation())) return;
    try {
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/tracks/`, { method: "DELETE", body: { song_ids: [trackId], lock_version: releaseRef.current?.lock_version } });
      replaceRelease(updated);
      showToast("Track removed from the release. The recording was kept.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not remove the track."), "error");
    }
  };

  const reorder = async (trackId: number, direction: -1 | 1) => {
    if (!release || readOnly || !(await prepareServerMutation())) return;
    const current = [...release.track_ids];
    const index = current.indexOf(trackId);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= current.length) return;
    [current[index], current[target]] = [current[target], current[index]];
    const orderedTracks = current
      .map((id) => release.tracks.find((item) => item.id === id))
      .filter((item): item is ReleaseTrackApi => Boolean(item));
    mutateRelease((draft) => ({ ...draft, track_ids: current, tracks: orderedTracks }));
    try {
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/tracks/`, { method: "POST", body: { action: "reorder", ordered_song_ids: current, lock_version: releaseRef.current?.lock_version } });
      replaceRelease(updated);
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not save the new track order."), "error");
      await loadRelease(true);
    }
  };

  const saveTrack = async (data: PartialSong) => {
    if (!editingTrack || !(await prepareServerMutation())) return;
    setEditingSong(true);
    try {
      const form = new FormData();
      const scalarFields: Array<keyof PartialSong> = [
        "title", "title_en", "release_date", "language", "description", "description_en", "lyrics", "lyrics_en",
        "tempo", "energy", "danceability", "valence", "acousticness", "instrumentalness", "speechiness",
        "label", "label_en", "credits", "credits_en",
      ];
      scalarFields.forEach((field) => {
        const value = data[field];
        if (value !== undefined && value !== null) form.set(String(field), String(value));
      });
      form.set("release_date", String(data.release_date || data.releaseDate || ""));
      form.set("is_single", "false");
      form.set("live_performed", String(Boolean(data.live_performed ?? data.liveness)));
      form.set("save_as_draft", "true");
      const addArray = (key: string, values?: unknown[]) => {
        if (values?.length) values.forEach((value) => form.append(key, String(value)));
        else form.append(key, "");
      };
      addArray("genre_ids", data.genre_ids);
      addArray("sub_genre_ids", data.sub_genre_ids);
      addArray("mood_ids", data.mood_ids);
      addArray("tag_ids", data.tag_ids);
      addArray("featured_artist_ids", data.featured_artist_ids);
      addArray("producers", data.producers);
      addArray("producers_en", data.producers_en);
      addArray("composers", data.composers);
      addArray("composers_en", data.composers_en);
      addArray("lyricists", data.lyricists);
      addArray("lyricists_en", data.lyricists_en);
      if (data.audio_file) form.set("audio_file", data.audio_file);
      if (data.cover_image) form.set("cover_image", data.cover_image);
      await apiRequest(`/artist/songs/${editingTrack.id}/`, { method: "PATCH", body: form });
      setEditingTrack(null);
      showToast("Track metadata saved as a private draft.", "success");
      await loadRelease(true);
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not save the track metadata."), "error");
    } finally {
      setEditingSong(false);
    }
  };

  const updateTrackExtras = (trackId: number, patch: Partial<ReleaseTrackExtras>) => {
    if (!release) return;
    const current = release.track_extras?.[String(trackId)] || {};
    updateRelease("track_extras", { ...release.track_extras, [String(trackId)]: { ...current, ...patch } });
  };

  const applyShared = async (songIds: number[]) => {
    if (!release || !songIds.length) return showToast("Select at least one track.", "error");
    const metadata = compactMetadata(release.shared_metadata);
    if (!Object.keys(metadata).length) return showToast("Enter at least one shared metadata value first.", "error");
    if (!(await prepareServerMutation())) return;
    setSubmitting(true);
    try {
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/bulk-metadata/`, {
        method: "POST",
        body: { song_ids: songIds, metadata, lock_version: releaseRef.current?.lock_version },
      });
      replaceRelease(updated);
      showToast(`Shared metadata applied to ${songIds.length} track${songIds.length === 1 ? "" : "s"}.`, "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not apply shared metadata."), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const copyMetadata = async () => {
    if (!release || !copySource || !selectedTracks.length) return showToast("Choose a source track and at least one destination track.", "error");
    const destinations = selectedTracks.filter((id) => id !== Number(copySource));
    if (!destinations.length) return showToast("Select at least one destination track different from the source.", "error");
    if (!(await prepareServerMutation())) return;
    setSubmitting(true);
    try {
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/bulk-metadata/`, {
        method: "POST",
        body: { song_ids: destinations, copy_from_song_id: Number(copySource), lock_version: releaseRef.current?.lock_version },
      });
      replaceRelease(updated);
      showToast("Metadata copied to the selected tracks.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not copy track metadata."), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const importCsv = async (file?: File) => {
    if (!file || !release) return;
    if (file.size > 2 * 1024 * 1024) return showToast("Metadata file must be smaller than 2MB.", "error");
    if (!(await prepareServerMutation())) return;
    setSubmitting(true);
    try {
      const rows = parseDelimitedText(await file.text());
      if (rows.length < 2) return showToast("The metadata file has no data rows.", "error");
      const headers = rows[0].map((item) => item.trim().toLowerCase());
      if (new Set(headers).size !== headers.length) return showToast("The metadata file contains duplicate column names.", "error");
      const trackColumn = headers.findIndex((item) => ["track", "track_number", "number"].includes(item));
      if (trackColumn < 0) return showToast("Add a track or track_number column to the CSV/TSV file.", "error");
      const supportedScalars = ["language", "label", "label_en", "credits", "credits_en"];
      const supportedLists = ["producers", "producers_en", "composers", "composers_en", "lyricists", "lyricists_en", "genre_ids", "sub_genre_ids", "mood_ids", "tag_ids"];
      const imported: Array<{ song_id: number; metadata: Record<string, unknown> }> = [];
      const seenTracks = new Set<number>();
      for (const [rowOffset, row] of rows.slice(1).entries()) {
        const trackNumber = Number(row[trackColumn]);
        if (!Number.isInteger(trackNumber) || trackNumber < 1 || trackNumber > release.tracks.length) {
          throw new Error(`Row ${rowOffset + 2} has an invalid track number.`);
        }
        if (seenTracks.has(trackNumber)) throw new Error(`Track ${trackNumber} appears more than once.`);
        seenTracks.add(trackNumber);
        const metadata: Record<string, unknown> = {};
        supportedScalars.forEach((key) => {
          const index = headers.indexOf(key);
          if (index >= 0 && row[index]?.trim()) metadata[key] = row[index].trim();
        });
        supportedLists.forEach((key) => {
          const index = headers.indexOf(key);
          if (index < 0 || !row[index]?.trim()) return;
          const values = textList(row[index]);
          metadata[key] = key.endsWith("_ids")
            ? values.map(Number).filter((value) => Number.isInteger(value) && value > 0)
            : values;
        });
        if (!Object.keys(metadata).length) continue;
        imported.push({ song_id: release.tracks[trackNumber - 1].id, metadata });
      }
      if (!imported.length) return showToast("No supported metadata values were found.", "error");
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/bulk-metadata/`, {
        method: "POST",
        body: { rows: imported, lock_version: releaseRef.current?.lock_version },
      });
      replaceRelease(updated);
      showToast(`Metadata imported for ${imported.length} track${imported.length === 1 ? "" : "s"}.`, "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, error instanceof Error ? error.message : "Could not import the metadata file."), "error");
    } finally {
      setSubmitting(false);
      if (csvRef.current) csvRef.current.value = "";
    }
  };

  const saveContributor = async () => {
    if (!newContributor.name.trim()) return showToast("Contributor name is required.", "error");
    try {
      const contributor = await apiRequest<ReleaseContributor>("/artist/contributors/", {
        method: "POST",
        body: { name: newContributor.name, name_en: newContributor.name_en, roles: [newContributor.role] },
      });
      setContributors((current) => [...current, contributor]);
      setNewContributor({ name: "", name_en: "", role: "producer" });
      showToast("Contributor profile saved.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not save the contributor profile."), "error");
    }
  };

  const applyContributor = (contributor: ReleaseContributor) => {
    const role = contributor.roles[0] || "producer";
    const key = role === "composer" ? "composers" : role === "lyricist" || role === "songwriter" ? "lyricists" : "producers";
    const keyEn = `${key}_en` as keyof SharedMetadata;
    updateShared({
      [key]: Array.from(new Set([...(release?.shared_metadata[key] as string[] || []), contributor.name])),
      [keyEn]: Array.from(new Set([...(release?.shared_metadata[keyEn] as string[] || []), contributor.name_en || contributor.name])),
    } as Partial<SharedMetadata>);
    showToast("Contributor added to shared metadata.", "success");
  };

  const uploadArtwork = async (file?: File) => {
    if (!file || !release) return;
    if (!file.size) return showToast("Artwork file is empty.", "error");
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) return showToast("Artwork must be JPG, PNG, or WEBP.", "error");
    if (file.size > 10 * 1024 * 1024) return showToast("Artwork must be smaller than 10MB.", "error");
    if (!(await prepareServerMutation())) return;
    setSubmitting(true);
    try {
      const { width, height } = await readImageDimensions(file);
      if (width !== height) throw new Error("Artwork must be square.");
      if (width < 1000 || height < 1000) throw new Error("Artwork must be at least 1000 × 1000 pixels.");
      const form = new FormData();
      form.set("cover_image", file);
      form.set("lock_version", String(releaseRef.current?.lock_version || release.lock_version));
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/artwork/`, { method: "POST", body: form });
      replaceRelease(updated);
      showToast("Release artwork uploaded successfully.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, error instanceof Error ? error.message : "Could not upload release artwork."), "error");
    } finally {
      setSubmitting(false);
      if (artworkRef.current) artworkRef.current.value = "";
    }
  };

  const requestValidation = async () => {
    if (!release) throw new Error("Release draft is not available.");
    const validation = await apiRequest<ArtistRelease["validation"]>(`/artist/releases/${release.id}/validate/`, { method: "POST", body: { lock_version: releaseRef.current?.lock_version } });
    mutateRelease((current) => ({ ...current, validation }));
    return validation;
  };

  const validateRelease = async () => {
    if (!release || submitting) return;
    setSubmitting(true);
    try {
      await persistLatestDraft(false);
      const validation = await requestValidation();
      if (validation.valid) showToast("Validation passed. The release is ready to submit.", "success");
      else showToast(`${validation.errors.length} blocking issue${validation.errors.length === 1 ? "" : "s"} must be fixed.`, "error");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not save and validate the latest release changes."), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const submitRelease = async () => {
    if (!release || submitting) return;
    setSubmitting(true);
    try {
      await persistLatestDraft(false);
      const updated = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/submit/`, { method: "POST", body: { lock_version: releaseRef.current?.lock_version } });
      replaceRelease(updated);
      showToast("Release submitted for review successfully.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "The release could not be submitted. Review the blocking issues."), "error");
      try { await requestValidation(); } catch { /* Preserve the original submission error. */ }
    } finally {
      setSubmitting(false);
    }
  };

  const createEditableCopy = async () => {
    if (!release || !readOnly || cloning) return;
    setCloning(true);
    try {
      const copy = await apiRequest<ArtistRelease>(`/artist/releases/${release.id}/clone/`, {
        method: "POST",
        body: { mode: release.status === "rejected" || release.status === "changes_requested" ? "revision" : "duplicate" },
      });
      showToast("An editable release copy was created. The submitted release was not changed.", "success");
      navigateTo("release-composer", { id: copy.id });
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not create an editable release copy."), "error");
    } finally {
      setCloning(false);
    }
  };

  const filteredRecordings = useMemo(() => {
    const needle = recordingQuery.trim().toLowerCase();
    const inRelease = new Set(release?.track_ids || []);
    return recordings.filter((item) => !inRelease.has(item.id) && (!needle || [item.title, item.title_en, item.album_title, item.artist_name].filter(Boolean).join(" ").toLowerCase().includes(needle)));
  }, [recordingQuery, recordings, release?.track_ids]);

  const extrasTrack = release?.tracks.find((track) => track.id === extrasTrackId) || null;
  const extras = extrasTrack ? release?.track_extras?.[String(extrasTrack.id)] || extrasTrack.release_extras || {} : {};
  const selectedReleaseArtists = (release?.release_metadata.release_artist_ids || [])
    .map((id) => artistDirectory[id])
    .filter((item): item is ArtistOption => Boolean(item));
  const addReleaseArtist = (artist: ArtistOption) => {
    if (!release || readOnly) return;
    const current = release.release_metadata.release_artist_ids || [];
    if (!current.includes(artist.id)) updateMetadata({ release_artist_ids: [...current, artist.id] });
    setArtistDirectory((items) => ({ ...items, [artist.id]: artist }));
    setReleaseArtistQuery("");
    setReleaseArtistResults([]);
  };
  const removeReleaseArtist = (artistId: number) => {
    if (!release || readOnly || artistId === release.primary_artist?.id) return;
    updateMetadata({ release_artist_ids: (release.release_metadata.release_artist_ids || []).filter((id) => id !== artistId) });
  };

  const focusIssue = (issue: ArtistRelease["validation"]["errors"][number]) => {
    if (issue.track_id) setExtrasTrackId(issue.track_id);
    if (issue.section === "tracklist") return goStep(2);
    if (["tracks", "audio", "rights", "credits"].includes(issue.section) && issue.track_id) return goStep(3);
    if (issue.section === "release" && /title|release type/i.test(issue.message)) return goStep(1);
    return goStep(5);
  };

  if (loading || !release) return <div className="flex min-h-[70vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-[#1DB954]" /></div>;

  const stepContent = () => {
    if (currentStep === 1) return <section className="space-y-6">
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.3fr)_minmax(260px,.7fr)]">
        <div className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <div><label className={labelClass}>عنوان انتشار (فارسی) *</label><input disabled={readOnly} className={inputClass} value={release.title} onChange={(event) => updateRelease("title", event.target.value)} placeholder="مثلاً شب‌های تهران" /></div>
            <div dir="ltr"><label className={`${labelClass} text-left`}>Release title (English)</label><input disabled={readOnly} className={`${inputClass} text-left`} value={release.title_en || ""} onChange={(event) => updateRelease("title_en", event.target.value)} placeholder="English release title" /></div>
          </div>
          <div><label className={labelClass}>نوع انتشار</label><div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">{releaseTypeOptions.map((option) => <button disabled={readOnly} key={option.value} type="button" onClick={() => updateRelease("release_type", option.value)} className={`min-h-24 rounded-xl border p-4 text-right transition ${release.release_type === option.value ? "border-[#1DB954] bg-[#1DB954]/10" : "border-[#303030] bg-[#181818] hover:border-[#4a4a4a]"}`}><p className="font-black text-white" dir="ltr">{option.title}</p><p className="mt-1 text-xs text-[#777]">{option.description}</p></button>)}</div></div>
          <div><label className={labelClass}>سابقه انتشار</label><div className="grid gap-2 sm:grid-cols-2"><button disabled={readOnly} type="button" onClick={() => updateRelease("previously_released", false)} className={`rounded-xl border p-4 text-right ${!release.previously_released ? "border-[#1DB954] bg-[#1DB954]/10" : "border-[#303030] bg-[#181818]"}`}><p className="font-black text-white">انتشار جدید</p><p className="mt-1 text-xs text-[#777]">برای اولین‌بار منتشر می‌شود.</p></button><button disabled={readOnly} type="button" onClick={() => updateRelease("previously_released", true)} className={`rounded-xl border p-4 text-right ${release.previously_released ? "border-[#1DB954] bg-[#1DB954]/10" : "border-[#303030] bg-[#181818]"}`}><p className="font-black text-white">قبلاً منتشرشده</p><p className="mt-1 text-xs text-[#777]">ISRC و تاریخ اصلی را در مراحل بعد وارد کنید.</p></button></div></div>
        </div>
        <aside className="border-r border-[#292929] pr-5 max-lg:border-r-0 max-lg:border-t max-lg:pt-5 max-lg:pr-0">
          <p className="text-xs font-black text-[#777]">هنرمند اصلی</p>
          <div className="mt-3 flex items-center gap-3"><div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-[#272727]">{release.primary_artist?.profile_image ? <img src={release.primary_artist.profile_image} alt="" className="h-full w-full object-cover" /> : <Users className="h-6 w-6 text-[#777]" />}</div><div><p className="font-black text-white">{release.primary_artist?.name}</p>{release.primary_artist?.name_en && <p className="text-xs text-[#777]" dir="ltr">{release.primary_artist.name_en}</p>}</div></div>
          <div className="mt-6 rounded-xl bg-[#1a1a1a] p-4 text-sm leading-6 text-[#909090]"><Info className="mb-2 h-5 w-5 text-[#1DB954]" />پیش‌نویس از همین حالا روی سرور ذخیره می‌شود. تا زمان ارسال نهایی هیچ آلبوم یا ترک جدیدی در اپ مخاطب نمایش داده نمی‌شود.</div>
        </aside>
      </div>
    </section>;

    if (currentStep === 2) return <section className="space-y-5">
      {!readOnly && <div className="grid gap-3 lg:grid-cols-2">
        <label onDragOver={(event) => { event.preventDefault(); if (!uploading) setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); if (!uploading) void uploadFiles(Array.from(event.dataTransfer.files)); }} className={`flex min-h-44 cursor-pointer items-center gap-4 rounded-2xl border border-dashed p-5 transition ${dragging ? "border-[#1DB954] bg-[#1DB954]/10" : "border-[#3a3a3a] bg-[#171717] hover:border-[#1DB954]/70"}`}><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[#1DB954]/10"><UploadCloud className="h-7 w-7 text-[#1DB954]" /></div><div><p className="text-lg font-black text-white">بارگذاری ترک‌های جدید</p><p className="mt-1 text-sm leading-6 text-[#777]">همه فایل‌های MP3 یا WAV را یکجا انتخاب یا Drag & Drop کنید. ترتیب انتخاب حفظ می‌شود.</p><button disabled={uploading} type="button" onClick={(event) => { event.preventDefault(); audioRef.current?.click(); }} className="mt-3 text-sm font-black text-[#1DB954] disabled:opacity-40">{uploading ? "در حال بارگذاری..." : "انتخاب فایل‌ها"}</button><input ref={audioRef} type="file" multiple accept=".mp3,.wav,audio/mpeg,audio/wav" hidden onChange={(event) => void uploadFiles(Array.from(event.target.files || []))} /></div></label>
        <button type="button" onClick={() => setExistingOpen(true)} className="flex min-h-44 items-center gap-4 rounded-2xl border border-[#333] bg-[#171717] p-5 text-right transition hover:border-[#1DB954]/70"><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-blue-500/10"><Library className="h-7 w-7 text-blue-300" /></div><div><p className="text-lg font-black text-white">افزودن از Recordings</p><p className="mt-1 text-sm leading-6 text-[#777]">پیش‌نویس‌ها، تک‌آهنگ‌های قبلی، نسخه‌های جایگزین یا آثار یک انتشار رهاشده را انتخاب کنید.</p><p className="mt-3 text-sm font-black text-blue-300">جستجو در آرشیو</p></div></button>
      </div>}
      {uploadProgress.length > 0 && <div className="divide-y divide-[#2b2b2b] rounded-xl border border-[#2b2b2b] bg-[#171717]">{uploadProgress.map((item) => <div key={item.id} className="flex items-center gap-3 px-4 py-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#242424]">{item.state === "uploading" ? <Loader2 className="h-4 w-4 animate-spin text-[#1DB954]" /> : item.state === "done" ? <Check className="h-4 w-4 text-[#1DB954]" /> : item.state === "error" ? <AlertCircle className="h-4 w-4 text-red-300" /> : <FileAudio className="h-4 w-4 text-[#777]" />}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-white">{item.name}</p>{item.message && <p className="mt-1 text-xs text-red-300">{item.message}</p>}</div><span className="text-xs text-[#777]">{item.state}</span></div>)}</div>}
      <TrackList release={release} readOnly={readOnly} onEdit={(track) => { setEditingTrack(track); setExtrasTrackId(track.id); }} onRemove={(id) => void removeTrack(id)} onMove={(id, direction) => void reorder(id, direction)} />
    </section>;

    if (currentStep === 3) return <section className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(320px,.48fr)]">
      <div><TrackList release={release} readOnly={readOnly} onEdit={(track) => { setExtrasTrackId(track.id); setEditingTrack(track); }} onSelectExtras={(id) => setExtrasTrackId(id)} onRemove={(id) => void removeTrack(id)} onMove={(id, direction) => void reorder(id, direction)} /></div>
      <aside className="h-fit rounded-2xl border border-[#2f2f2f] bg-[#161616] p-4 xl:sticky xl:top-4">
        {extrasTrack ? <div className="space-y-4"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-black text-[#1DB954]">TRACK {release.track_ids.indexOf(extrasTrack.id) + 1}</p><h3 className="mt-1 text-lg font-black text-white">{extrasTrack.title}</h3><p className="mt-1 text-xs text-[#777]">اطلاعات تکمیلی حقوق، مالکیت و پلتفرم</p></div><button onClick={() => setEditingTrack(extrasTrack)} className="rounded-lg bg-[#252525] px-3 py-2 text-xs font-black text-white">فرم کامل</button></div>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2"><div><label className={labelClass}>ISRC</label><input disabled={readOnly} dir="ltr" className={`${inputClass} text-left`} value={String(extras.isrc || "")} onChange={(event) => updateTrackExtras(extrasTrack.id, { isrc: event.target.value.toUpperCase() })} placeholder="IR-XXX-26-00001" /></div><div><label className={labelClass}>نسخه</label><input disabled={readOnly} className={inputClass} value={String(extras.version || "")} onChange={(event) => updateTrackExtras(extrasTrack.id, { version: event.target.value })} placeholder="Original / Acoustic / Remix" /></div><div><label className={labelClass}>مالک مستر</label><input disabled={readOnly} className={inputClass} value={String(extras.master_owner || "")} onChange={(event) => updateTrackExtras(extrasTrack.id, { master_owner: event.target.value })} /></div><div><label className={labelClass}>مالک نشر</label><input disabled={readOnly} className={inputClass} value={String(extras.publishing_owner || "")} onChange={(event) => updateTrackExtras(extrasTrack.id, { publishing_owner: event.target.value })} /></div><div><label className={labelClass}>شروع Preview (ثانیه)</label><input disabled={readOnly} type="number" min={0} max={Math.max(0, Number(extrasTrack.duration_seconds || 1) - 1)} className={inputClass} value={Number(extras.preview_start || 0)} onChange={(event) => updateTrackExtras(extrasTrack.id, { preview_start: Number(event.target.value) })} /></div><div><label className={labelClass}>شماره دیسک</label><input disabled={readOnly} type="number" min={1} max={99} className={inputClass} value={Number(extras.disc_number || 1)} onChange={(event) => updateTrackExtras(extrasTrack.id, { disc_number: Number(event.target.value) })} /></div><div><label className={labelClass}>شماره ترک در دیسک</label><input disabled={readOnly} type="number" min={1} max={999} className={inputClass} value={Number(extras.track_number || release.track_ids.indexOf(extrasTrack.id) + 1)} onChange={(event) => updateTrackExtras(extrasTrack.id, { track_number: Number(event.target.value) })} /></div><label className="flex items-center justify-between rounded-xl border border-[#333] bg-[#1a1a1a] p-3"><span className="text-sm font-bold text-white">Explicit</span><input disabled={readOnly} type="checkbox" checked={Boolean(extras.explicit)} onChange={(event) => updateTrackExtras(extrasTrack.id, { explicit: event.target.checked })} className="h-5 w-5 accent-[#1DB954]" /></label></div>
          <SplitEditor readOnly={readOnly} value={extras.songwriter_splits || []} onChange={(value) => updateTrackExtras(extrasTrack.id, { songwriter_splits: value })} />
          <div><label className={labelClass}>مجوزها</label><input disabled={readOnly} className={inputClass} value={(extras.licenses || []).join(", ")} onChange={(event) => updateTrackExtras(extrasTrack.id, { licenses: textList(event.target.value) })} placeholder="Mechanical, cover, sample clearance..." /></div><div><label className={labelClass}>یادداشت حقوق و مجوز</label><textarea disabled={readOnly} rows={4} className={`${inputClass} resize-y`} value={String(extras.rights_notes || "")} onChange={(event) => updateTrackExtras(extrasTrack.id, { rights_notes: event.target.value })} /></div>
        </div> : <div className="py-12 text-center text-sm text-[#777]">یک ترک را برای ویرایش انتخاب کنید.</div>}
      </aside>
    </section>;

    if (currentStep === 4) return <section className="space-y-6">
      <div className="flex flex-col gap-3 border-b border-[#292929] pb-5 lg:flex-row lg:items-center lg:justify-between"><div><h2 className="text-xl font-black text-white">متادیتای مشترک</h2><p className="mt-1 text-sm text-[#777]">اطلاعات تکراری را یک‌بار وارد و روی همه یا ترک‌های انتخابی اعمال کنید.</p></div><div className="flex flex-wrap gap-2"><button disabled={readOnly || submitting} onClick={() => void applyShared(release.track_ids)} className="rounded-xl bg-[#1DB954] px-4 py-2.5 text-sm font-black text-black">اعمال روی همه</button><button disabled={readOnly || submitting || !selectedTracks.length} onClick={() => void applyShared(selectedTracks)} className="rounded-xl border border-[#3a3a3a] bg-[#1d1d1d] px-4 py-2.5 text-sm font-black text-white">اعمال روی انتخاب‌شده</button></div></div>
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(320px,.8fr)]"><div className="space-y-5"><div className="grid gap-4 md:grid-cols-3"><div><label className={labelClass}>زبان</label><select disabled={readOnly} className={inputClass} value={release.shared_metadata.language || "fa"} onChange={(event) => updateShared({ language: event.target.value })}><option value="fa">فارسی</option><option value="en">English</option><option value="ar">العربية</option><option value="other">سایر</option></select></div><div><label className={labelClass}>لیبل (فارسی)</label><input disabled={readOnly} className={inputClass} value={release.shared_metadata.label || ""} onChange={(event) => updateShared({ label: event.target.value })} /></div><div dir="ltr"><label className={`${labelClass} text-left`}>Label (English)</label><input disabled={readOnly} className={`${inputClass} text-left`} value={release.shared_metadata.label_en || ""} onChange={(event) => updateShared({ label_en: event.target.value })} /></div></div>
        <div className="grid gap-4 lg:grid-cols-2"><TaxonomySelector label="ژانرها" items={taxonomies.genres} value={release.shared_metadata.genre_ids} onChange={(value) => updateShared({ genre_ids: value })} disabled={readOnly} /><TaxonomySelector label="حال‌وهوا" items={taxonomies.moods} value={release.shared_metadata.mood_ids} onChange={(value) => updateShared({ mood_ids: value })} disabled={readOnly} /><TaxonomySelector label="زیرژانرها" items={taxonomies.subgenres} value={release.shared_metadata.sub_genre_ids} onChange={(value) => updateShared({ sub_genre_ids: value })} disabled={readOnly} /><TaxonomySelector label="تگ‌ها" items={taxonomies.tags} value={release.shared_metadata.tag_ids} onChange={(value) => updateShared({ tag_ids: value })} disabled={readOnly} /></div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{([ ["producers", "تهیه‌کنندگان"], ["composers", "آهنگسازان"], ["lyricists", "ترانه‌سرایان"] ] as const).map(([key, label]) => <div key={key}><label className={labelClass}>{label}</label><input disabled={readOnly} className={inputClass} value={listText(release.shared_metadata[key])} onChange={(event) => updateShared({ [key]: textList(event.target.value) } as Partial<SharedMetadata>)} placeholder="نام‌ها را با ویرگول جدا کنید" /></div>)}</div>
        <div className="grid gap-3 md:grid-cols-[1fr_1fr_auto]"><select className={inputClass} value={copySource} onChange={(event) => setCopySource(event.target.value ? Number(event.target.value) : "")}><option value="">کپی متادیتا از یک ترک</option>{release.tracks.map((track, index) => <option key={track.id} value={track.id}>{index + 1}. {track.title}</option>)}</select><button disabled={readOnly || !copySource || !selectedTracks.length} onClick={() => void copyMetadata()} className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#3a3a3a] bg-[#1d1d1d] px-4 py-3 font-black text-white disabled:opacity-40"><ClipboardCopy className="h-4 w-4" />کپی روی انتخاب‌شده</button><button disabled={readOnly} onClick={() => csvRef.current?.click()} className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#3a3a3a] bg-[#1d1d1d] px-4 py-3 font-black text-white"><FileSpreadsheet className="h-4 w-4" />CSV/TSV<input ref={csvRef} type="file" accept=".csv,.tsv,text/csv,text/tab-separated-values" hidden onChange={(event) => void importCsv(event.target.files?.[0])} /></button></div></div>
        <aside className="space-y-4"><div className="rounded-xl border border-[#303030] bg-[#171717] p-4"><div className="mb-3 flex items-center justify-between"><h3 className="font-black text-white">انتخاب ترک‌ها</h3><button onClick={() => setSelectedTracks(selectedTracks.length === release.track_ids.length ? [] : release.track_ids)} className="text-xs font-black text-[#1DB954]">{selectedTracks.length === release.track_ids.length ? "لغو همه" : "انتخاب همه"}</button></div><div className="max-h-64 space-y-1 overflow-y-auto">{release.tracks.map((track, index) => <label key={track.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-[#222]"><input type="checkbox" checked={selectedTracks.includes(track.id)} onChange={() => setSelectedTracks((current) => current.includes(track.id) ? current.filter((id) => id !== track.id) : [...current, track.id])} className="h-4 w-4 accent-[#1DB954]" /><span className="text-xs text-[#777]">{index + 1}</span><span className="min-w-0 flex-1 truncate text-sm font-bold text-white">{track.title}</span></label>)}</div></div>
        <div className="rounded-xl border border-[#303030] bg-[#171717] p-4"><h3 className="mb-3 font-black text-white">پروفایل عوامل</h3><div className="space-y-2">{contributors.slice(0, 8).map((contributor) => <button key={contributor.id} onClick={() => applyContributor(contributor)} className="flex w-full items-center gap-3 rounded-lg bg-[#202020] px-3 py-2 text-right hover:bg-[#292929]"><UserPlus className="h-4 w-4 text-[#1DB954]" /><span className="min-w-0 flex-1 truncate text-sm font-bold text-white">{contributor.name}</span><span className="text-[10px] text-[#777]">{contributor.roles.join(", ")}</span></button>)}</div><div className="mt-4 grid gap-2"><input className={inputClass} value={newContributor.name} onChange={(event) => setNewContributor({ ...newContributor, name: event.target.value })} placeholder="نام عامل" /><div className="grid grid-cols-[1fr_auto] gap-2"><select className={inputClass} value={newContributor.role} onChange={(event) => setNewContributor({ ...newContributor, role: event.target.value })}><option value="producer">Producer</option><option value="composer">Composer</option><option value="lyricist">Lyricist</option><option value="performer">Performer</option></select><button disabled={readOnly} onClick={() => void saveContributor()} className="rounded-xl bg-[#2a2a2a] px-4 font-black text-white">ذخیره</button></div></div></div></aside></div>
    </section>;

    if (currentStep === 5) return <section className="grid gap-6 xl:grid-cols-[280px_minmax(0,1fr)]">
      <div><label className={labelClass}>کاور انتشار *</label><button disabled={readOnly || submitting} onClick={() => artworkRef.current?.click()} className="relative flex aspect-square w-full items-center justify-center overflow-hidden rounded-2xl border border-dashed border-[#3b3b3b] bg-[#171717] transition hover:border-[#1DB954]">{release.release_metadata.cover_url ? <img src={release.release_metadata.cover_url} alt="Release artwork" className="absolute inset-0 h-full w-full object-cover" /> : <div className="text-center"><ImagePlus className="mx-auto h-9 w-9 text-[#1DB954]" /><p className="mt-3 font-black text-white">بارگذاری کاور</p><p className="mt-1 text-xs text-[#777]">JPG, PNG, WEBP تا 10MB</p></div>}<span className="absolute inset-0 bg-black/0 transition hover:bg-black/20" /><input ref={artworkRef} type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={(event) => void uploadArtwork(event.target.files?.[0])} /></button><p className="mt-3 text-xs leading-5 text-[#6f6f6f]">پیشنهاد: تصویر مربع حداقل 3000×3000، بدون حاشیه و متن بریده‌شده.</p></div>
      <div className="space-y-5"><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3"><div><label className={labelClass}>تاریخ انتشار *</label><input disabled={readOnly} type="date" min={release.previously_released ? undefined : todayIso} dir="ltr" className={`${inputClass} text-left`} value={release.release_metadata.release_date || ""} onChange={(event) => updateMetadata({ release_date: event.target.value })} /></div><div><label className={labelClass}>تاریخ انتشار اصلی</label><input disabled={readOnly} type="date" dir="ltr" className={`${inputClass} text-left`} value={release.release_metadata.original_release_date || ""} onChange={(event) => updateMetadata({ original_release_date: event.target.value })} /></div><div><label className={labelClass}>UPC / EAN</label><input disabled={readOnly} dir="ltr" className={`${inputClass} text-left`} value={release.release_metadata.upc || ""} onChange={(event) => updateMetadata({ upc: event.target.value.replace(/\D/g, "").slice(0, 14) })} placeholder="Optional" /></div><div><label className={labelClass}>ژانر اصلی *</label><select disabled={readOnly} className={inputClass} value={release.release_metadata.primary_genre_id || ""} onChange={(event) => updateMetadata({ primary_genre_id: event.target.value ? Number(event.target.value) : null })}><option value="">انتخاب کنید</option>{taxonomies.genres.map((item) => <option key={item.id} value={item.id}>{item.title || item.name}</option>)}</select></div><div><label className={labelClass}>ژانر دوم</label><select disabled={readOnly} className={inputClass} value={release.release_metadata.secondary_genre_id || ""} onChange={(event) => updateMetadata({ secondary_genre_id: event.target.value ? Number(event.target.value) : null })}><option value="">بدون ژانر دوم</option>{taxonomies.genres.filter((item) => item.id !== release.release_metadata.primary_genre_id).map((item) => <option key={item.id} value={item.id}>{item.title || item.name}</option>)}</select></div><div><label className={labelClass}>لیبل</label><input disabled={readOnly} className={inputClass} value={release.release_metadata.label || ""} onChange={(event) => updateMetadata({ label: event.target.value })} /></div></div>
        <div className="rounded-2xl border border-[#303030] bg-[#171717] p-4 sm:p-5"><div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="font-black text-white">هنرمندان سطح انتشار</h3><p className="mt-1 text-xs leading-5 text-[#777]">هنرمند اصلی همیشه حفظ می‌شود. برای همکاری مشترک یا Compilation هنرمندان دیگر را اضافه کنید.</p></div><span className="mt-2 w-fit rounded-full bg-[#252525] px-3 py-1 text-xs font-black text-[#aaa] sm:mt-0">{selectedReleaseArtists.length} artist</span></div><div className="relative mt-4"><Search className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-[#666]" /><input disabled={readOnly} className={`${inputClass} pr-11`} value={releaseArtistQuery} onChange={(event) => setReleaseArtistQuery(event.target.value)} placeholder="حداقل دو حرف از نام هنرمند را جستجو کنید" />{searchingReleaseArtists && <Loader2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-[#1DB954]" />}{releaseArtistResults.length > 0 && <div className="absolute inset-x-0 top-[calc(100%+8px)] z-20 max-h-56 overflow-y-auto rounded-xl border border-[#353535] bg-[#111] p-2 shadow-2xl">{releaseArtistResults.map((artist) => <button key={artist.id} type="button" onClick={() => addReleaseArtist(artist)} className="flex w-full items-center gap-3 rounded-lg p-2 text-right hover:bg-[#252525]"><div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-[#292929]">{artist.profile_image ? <img src={artist.profile_image} alt="" className="h-full w-full object-cover" /> : <Users className="m-2.5 h-5 w-5 text-[#777]" />}</div><div className="min-w-0"><p className="truncate font-bold text-white">{artist.artistic_name || artist.name}</p>{(artist.artistic_name_en || artist.name_en) && <p className="truncate text-xs text-[#777]" dir="ltr">{artist.artistic_name_en || artist.name_en}</p>}</div></button>)}</div>}</div><div className="mt-3 flex flex-wrap gap-2">{selectedReleaseArtists.map((artist) => { const primary = artist.id === release.primary_artist?.id; return <span key={artist.id} className="inline-flex items-center gap-2 rounded-full bg-[#252525] py-1.5 pr-3 pl-1.5 text-sm font-bold text-white"><span>{artist.artistic_name || artist.name}</span>{primary ? <span className="rounded-full bg-[#1DB954]/15 px-2 py-0.5 text-[10px] font-black text-[#1DB954]">PRIMARY</span> : <button type="button" disabled={readOnly} onClick={() => removeReleaseArtist(artist.id)} className="rounded-full bg-[#3a3a3a] p-1 text-[#aaa] hover:bg-red-500 hover:text-white"><X className="h-3 w-3" /></button>}</span>; })}</div></div>
        <div className="grid gap-4 md:grid-cols-2"><div><label className={labelClass}>℗ مالک ضبط</label><input disabled={readOnly} className={inputClass} value={release.release_metadata.p_copyright || ""} onChange={(event) => updateMetadata({ p_copyright: event.target.value })} placeholder="2026 Artist / Label" /></div><div><label className={labelClass}>© مالک اثر و کاور</label><input disabled={readOnly} className={inputClass} value={release.release_metadata.c_copyright || ""} onChange={(event) => updateMetadata({ c_copyright: event.target.value })} placeholder="2026 Artist / Label" /></div></div>
        <div className="grid gap-4 lg:grid-cols-2"><ChoiceChips label="قلمروها" options={["WORLDWIDE", "IR", "US", "CA", "EU", "UK", "AE", "TR"]} value={release.release_metadata.territories || []} onChange={(territories) => updateMetadata({ territories })} disabled={readOnly} /><ChoiceChips label="پلتفرم‌های توزیع" options={["SEDABOX", "SPOTIFY", "APPLE_MUSIC", "YOUTUBE_MUSIC", "SOUNDCLOUD", "BANDCAMP"]} value={release.release_metadata.platforms || []} onChange={(platforms) => updateMetadata({ platforms })} disabled={readOnly} /></div>
        <div className="grid gap-4 lg:grid-cols-[220px_1fr]"><label className="flex items-center justify-between rounded-xl border border-[#343434] bg-[#1a1a1a] p-4"><div><p className="font-black text-white">Pre-order</p><p className="mt-1 text-xs text-[#777]">فعال‌سازی پیش‌خرید</p></div><input disabled={readOnly} type="checkbox" checked={Boolean(release.release_metadata.preorder_enabled)} onChange={(event) => updateMetadata({ preorder_enabled: event.target.checked })} className="h-5 w-5 accent-[#1DB954]" /></label>{release.release_metadata.preorder_enabled && <div><label className={labelClass}>تاریخ شروع Pre-order</label><input disabled={readOnly} type="date" min={todayIso} max={release.release_metadata.release_date || undefined} dir="ltr" className={`${inputClass} text-left`} value={release.release_metadata.preorder_date || ""} onChange={(event) => updateMetadata({ preorder_date: event.target.value })} /></div>}</div>
        <div className="rounded-xl border border-blue-500/15 bg-blue-500/10 p-4 text-xs leading-6 text-blue-100"><Info className="mb-2 h-4 w-4" />انتخاب پلتفرم و قلمرو در این مرحله، متادیتای برنامه‌ریزی انتشار Sedabox است. ارسال خودکار به سرویس‌های خارجی فقط در صورت اتصال جداگانه سرویس توزیع انجام می‌شود.</div><div className="grid gap-4 lg:grid-cols-2"><div><label className={labelClass}>توضیحات انتشار (فارسی)</label><textarea disabled={readOnly} rows={4} className={`${inputClass} resize-y`} value={release.release_metadata.description || ""} onChange={(event) => updateMetadata({ description: event.target.value })} /></div><div dir="ltr"><label className={`${labelClass} text-left`}>Release description (English)</label><textarea disabled={readOnly} rows={4} className={`${inputClass} resize-y text-left`} value={release.release_metadata.description_en || ""} onChange={(event) => updateMetadata({ description_en: event.target.value })} /></div></div></div>
    </section>;

    return <section className="space-y-6"><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{[
      ["اطلاعات انتشار", release.validation.summary.release_information, release.title],
      ["کاور", release.validation.summary.artwork, release.validation.summary.artwork ? "آماده" : "نیاز به تکمیل"],
      ["ترک‌لیست", release.validation.summary.track_count > 0, `${release.validation.summary.track_count} ترک`],
      ["فایل‌های صوتی", release.validation.summary.audio_passed, release.validation.summary.audio_passed ? "تأیید شد" : "ناقص"],
      ["متادیتای ترک‌ها", release.validation.summary.complete_tracks === release.validation.summary.track_count && release.validation.summary.track_count > 0, `${release.validation.summary.complete_tracks}/${release.validation.summary.track_count} کامل`],
      ["حقوق و مجوز", release.validation.summary.rights_warnings === 0, `${release.validation.summary.rights_warnings} هشدار`],
    ].map(([label, complete, value]) => <div key={String(label)} className="flex items-center gap-3 border-b border-[#292929] bg-[#171717] p-4 sm:rounded-xl sm:border"><span className={`flex h-10 w-10 items-center justify-center rounded-xl ${complete ? "bg-[#1DB954]/10 text-[#1DB954]" : "bg-amber-500/10 text-amber-300"}`}>{complete ? <CheckCircle2 className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}</span><div><p className="text-xs text-[#777]">{label}</p><p className="mt-1 font-black text-white">{value}</p></div></div>)}</div>
      <div className="grid gap-5 xl:grid-cols-2"><div><div className="mb-3 flex items-center gap-2"><AlertCircle className="h-5 w-5 text-red-300" /><h3 className="font-black text-white">خطاهای مسدودکننده</h3><span className="rounded-full bg-red-500/10 px-2 py-0.5 text-xs font-black text-red-300">{release.validation.errors.length}</span></div><div className="space-y-2">{release.validation.errors.length ? release.validation.errors.map((issue, index) => <button key={`${issue.message}-${index}`} onClick={() => focusIssue(issue)} className="flex w-full items-start gap-3 rounded-xl border border-red-500/15 bg-red-500/10 p-3 text-right"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-300" /><span className="text-sm leading-6 text-red-100">{issue.message}</span></button>) : <div className="rounded-xl border border-[#1DB954]/15 bg-[#1DB954]/10 p-4 text-sm text-emerald-100">هیچ خطای مسدودکننده‌ای وجود ندارد.</div>}</div></div><div><div className="mb-3 flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-amber-300" /><h3 className="font-black text-white">هشدارها</h3><span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-xs font-black text-amber-300">{release.validation.warnings.length}</span></div><div className="space-y-2">{release.validation.warnings.length ? release.validation.warnings.map((issue, index) => <button key={`${issue.message}-${index}`} onClick={() => focusIssue(issue)} className="flex w-full items-start gap-3 rounded-xl border border-amber-500/15 bg-amber-500/10 p-3 text-right"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /><span className="text-sm leading-6 text-amber-100">{issue.message}</span></button>) : <div className="rounded-xl border border-[#303030] bg-[#171717] p-4 text-sm text-[#888]">هشداری وجود ندارد.</div>}</div></div></div>
      {!readOnly && <div className="flex flex-col gap-3 rounded-2xl border border-[#303030] bg-[#171717] p-5 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="font-black text-white">آماده ارسال نهایی هستید؟</h3><p className="mt-1 text-sm text-[#777]">بعد از ارسال، ساختار انتشار قفل می‌شود و همه ترک‌ها برای بررسی به Pending می‌روند.</p></div><div className="flex gap-2"><button disabled={submitting} onClick={() => void validateRelease()} className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#3a3a3a] bg-[#222] px-4 py-3 font-black text-white"><RefreshCw className={`h-4 w-4 ${submitting ? "animate-spin" : ""}`} />اعتبارسنجی دوباره</button><button disabled={submitting || !release.validation.valid} onClick={() => void submitRelease()} className="inline-flex min-w-44 items-center justify-center gap-2 rounded-xl bg-[#1DB954] px-5 py-3 font-black text-black disabled:opacity-40">{submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}ارسال برای بررسی</button></div></div>}
      {readOnly && <div className="flex flex-col gap-4 rounded-2xl border border-[#1DB954]/15 bg-[#1DB954]/10 p-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-3"><CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-[#1DB954]" /><div><h3 className="font-black text-white">وضعیت: {releaseStatusLabels[release.status]}</h3><p className="mt-1 text-sm leading-6 text-[#9a9a9a]">{release.review_note || "ساختار این نسخه قفل است تا نسخه بررسی‌شده دقیقاً همان چیزی بماند که ارسال کرده‌اید."}</p>{release.status === "scheduled" && release.scheduled_at && <p className="mt-2 text-xs font-bold text-blue-200">زمان انتشار: {new Intl.DateTimeFormat("fa-IR", { dateStyle: "long", timeStyle: "short" }).format(new Date(release.scheduled_at))}</p>}</div></div><button disabled={cloning} onClick={() => void createEditableCopy()} className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-black text-black disabled:opacity-50">{cloning ? <Loader2 className="h-4 w-4 animate-spin" /> : <CopyPlus className="h-4 w-4" />}{release.status === "changes_requested" || release.status === "rejected" ? "ساخت نسخه اصلاحی" : "ساخت نسخه قابل‌ویرایش"}</button></div>}
    </section>;
  };

  return <div id="release-composer-top" className="min-h-full w-full pb-28" dir="rtl">
    <header className="sticky top-0 z-30 border-b border-[#272727] bg-[#101010]/95 px-4 py-4 backdrop-blur-xl sm:px-6 lg:px-8"><div className="mx-auto flex max-w-[1500px] items-center gap-3"><button onClick={() => void leaveComposer()} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#222] text-white hover:bg-[#2d2d2d]"><ArrowRight className="h-5 w-5" /></button><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h1 className="truncate text-lg font-black text-white sm:text-xl">{release.title || "Untitled Release"}</h1><span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-black ${readOnly ? "bg-amber-500/10 text-amber-300" : "bg-white/10 text-[#aaa]"}`}>{releaseStatusLabels[release.status]}</span></div><div className="mt-1 flex items-center gap-2 text-[11px] text-[#6f6f6f]">{saving ? <><Loader2 className="h-3.5 w-3.5 animate-spin text-[#1DB954]" />در حال ذخیره...</> : <><CloudUpload className="h-3.5 w-3.5 text-[#1DB954]" />ذخیره خودکار{savedAt ? ` · ${savedAt}` : ""}</>}</div></div><button disabled={saving || submitting} onClick={() => void refreshComposer()} className="flex h-10 disabled:opacity-40 w-10 items-center justify-center rounded-xl bg-[#222] text-white"><RefreshCw className="h-4 w-4" /></button></div></header>

    <div className="mx-auto max-w-[1500px] px-4 py-5 sm:px-6 lg:px-8"><nav className="mb-6 overflow-x-auto"><div className="flex min-w-max items-center gap-1 rounded-xl bg-[#171717] p-1 lg:min-w-0">{stepNames.map((name, index) => { const step = index + 1; const active = currentStep === step; const done = step < currentStep; return <button key={name} onClick={() => goStep(step)} className={`flex min-w-36 flex-1 items-center gap-2 rounded-lg px-3 py-2.5 text-right transition ${active ? "bg-white text-black" : "text-[#858585] hover:bg-[#222] hover:text-white"}`}><span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-black ${done ? "bg-[#1DB954] text-black" : active ? "bg-black text-white" : "bg-[#292929]"}`}>{done ? <Check className="h-3.5 w-3.5" /> : step}</span><span className="truncate text-xs font-black">{name}</span></button>; })}</div></nav><main className="rounded-2xl border border-[#292929] bg-[#131313] p-4 sm:p-5 lg:p-6">{stepContent()}</main></div>

    <footer className="fixed inset-x-0 bottom-0 z-40 border-t border-[#292929] bg-[#101010]/96 px-4 py-3 backdrop-blur-xl sm:px-6 lg:pr-[calc(16rem+1.5rem)]"><div className="mx-auto flex max-w-[1500px] items-center justify-between gap-3"><button disabled={currentStep === 1} onClick={() => goStep(currentStep - 1)} className="inline-flex items-center gap-2 rounded-xl border border-[#343434] bg-[#1d1d1d] px-4 py-2.5 font-black text-white disabled:opacity-30"><ArrowRight className="h-4 w-4" />قبلی</button><div className="hidden text-xs text-[#6f6f6f] sm:block">مرحله {currentStep} از 6 · {release.tracks.length} ترک</div>{currentStep < 6 ? <button onClick={() => goStep(currentStep + 1)} className="inline-flex items-center gap-2 rounded-xl bg-[#1DB954] px-5 py-2.5 font-black text-black">بعدی<ArrowLeft className="h-4 w-4" /></button> : <button disabled={readOnly || submitting || !release.validation.valid} onClick={() => void submitRelease()} className="inline-flex items-center gap-2 rounded-xl bg-[#1DB954] px-5 py-2.5 font-black text-black disabled:opacity-40"><Send className="h-4 w-4" />ارسال نهایی</button>}</div></footer>

    <SongModal isOpen={Boolean(editingTrack)} onClose={() => !editingSong && setEditingTrack(null)} onSubmit={saveTrack} initialData={editingTrack ? mapTrackToSong(editingTrack) : null} initialIsSingle={false} isSubmitting={editingSong} allowIncomplete draftMode submitLabel="ذخیره پیش‌نویس ترک" />

    {existingOpen && <div className="fixed inset-0 z-[110] flex items-end justify-center bg-black/80 backdrop-blur-sm sm:items-center sm:p-4"><div className="flex h-[88dvh] w-full max-w-4xl flex-col overflow-hidden rounded-t-3xl border border-[#303030] bg-[#121212] sm:rounded-3xl"><header className="flex items-center justify-between border-b border-[#292929] p-4 sm:px-5"><div><h2 className="text-xl font-black text-white">افزودن از Recordings</h2><p className="mt-1 text-xs text-[#777]">انتخاب آثار منتشرشده، منتشرنشده یا پیش‌نویس</p></div><button onClick={() => setExistingOpen(false)} className="flex h-10 w-10 items-center justify-center rounded-full bg-[#252525] text-white"><X className="h-5 w-5" /></button></header><div className="border-b border-[#292929] p-4"><div className="relative"><Search className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-[#666]" /><input className={`${inputClass} pr-11`} value={recordingQuery} onChange={(event) => setRecordingQuery(event.target.value)} placeholder="جستجو در ضبط‌ها" /></div></div><div className="flex-1 overflow-y-auto p-3 sm:p-4">{recordingsLoading ? <div className="flex min-h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-[#1DB954]" /></div> : <><div className="space-y-1">{filteredRecordings.map((track) => <label key={track.id} className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition ${selectedExisting.includes(track.id) ? "border-[#1DB954] bg-[#1DB954]/10" : "border-transparent hover:bg-[#1c1c1c]"}`}><input type="checkbox" checked={selectedExisting.includes(track.id)} onChange={() => setSelectedExisting((current) => current.includes(track.id) ? current.filter((id) => id !== track.id) : [...current, track.id])} className="h-5 w-5 accent-[#1DB954]" /><div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-lg bg-[#252525]">{track.cover_image ? <img src={track.cover_image} alt="" className="h-full w-full object-cover" /> : <Music2 className="h-5 w-5 text-[#666]" />}</div><div className="min-w-0 flex-1"><p className="truncate font-black text-white">{track.title}</p><p className="mt-1 truncate text-xs text-[#777]">{track.album_title || (track.status === "published" ? "Released single" : track.status === "draft" ? "Draft metadata" : "Unreleased")}</p></div><span className="rounded-full bg-[#252525] px-2.5 py-1 text-[10px] font-bold text-[#aaa]">{track.status}</span></label>)}</div>{!filteredRecordings.length && <div className="py-16 text-center text-sm text-[#777]">ضبطی پیدا نشد.</div>}</>}</div><footer className="flex items-center justify-between border-t border-[#292929] p-4"><p className="text-xs text-[#777]">{selectedExisting.length} انتخاب‌شده</p><button disabled={!selectedExisting.length || submitting} onClick={() => void addExisting()} className="inline-flex min-w-40 items-center justify-center gap-2 rounded-xl bg-[#1DB954] px-5 py-2.5 font-black text-black disabled:opacity-40">{submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Plus className="h-5 w-5" />}افزودن</button></footer></div></div>}
  </div>;
};

const TrackList: React.FC<{ release: ArtistRelease; readOnly: boolean; onEdit: (track: ReleaseTrackApi) => void; onSelectExtras?: (id: number) => void; onRemove: (id: number) => void; onMove: (id: number, direction: -1 | 1) => void }> = ({ release, readOnly, onEdit, onSelectExtras, onRemove, onMove }) => <div className="overflow-hidden rounded-2xl border border-[#2c2c2c] bg-[#161616]"><div className="hidden grid-cols-[48px_minmax(240px,1fr)_130px_160px_130px] gap-3 border-b border-[#292929] px-4 py-3 text-xs font-black text-[#666] lg:grid"><span>#</span><span>ترک</span><span>فایل</span><span>متادیتا</span><span className="text-left">عملیات</span></div><div className="divide-y divide-[#292929]">{release.tracks.map((track, index) => { const complete = track.metadata_completion >= 80; const numbering = release.track_extras?.[String(track.id)] || track.release_extras || {}; const discNumber = Number(numbering.disc_number || 1); const trackNumber = Number(numbering.track_number || index + 1); return <article key={track.id} onClick={() => onSelectExtras?.(track.id)} className="grid gap-3 p-3 transition hover:bg-[#1c1c1c] lg:grid-cols-[48px_minmax(240px,1fr)_130px_160px_130px] lg:items-center lg:px-4"><div className="flex items-center gap-1"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#242424] text-sm font-black text-white">{discNumber > 1 ? `${discNumber}.${trackNumber}` : trackNumber}</span></div><div className="flex min-w-0 items-center gap-3"><div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-[#252525]">{track.cover_image ? <img src={track.cover_image} alt="" className="h-full w-full object-cover" /> : <FileAudio className="h-5 w-5 text-[#666]" />}</div><div className="min-w-0"><p className="truncate font-black text-white">{track.title}</p>{track.title_en && <p className="truncate text-xs text-[#727272]" dir="ltr">{track.title_en}</p>}<p className="mt-1 text-[11px] text-[#656565]">{track.duration_display || "0:00"} · {(track.original_format || "audio").toUpperCase()} · {track.status}</p></div></div><span className={`inline-flex w-fit items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${track.has_audio ? "bg-[#1DB954]/10 text-[#1DB954]" : "bg-red-500/10 text-red-300"}`}>{track.has_audio ? <CheckCircle2 className="h-3.5 w-3.5" /> : <AlertCircle className="h-3.5 w-3.5" />}{track.has_audio ? "Audio valid" : "Missing audio"}</span><div><div className="mb-1 flex items-center justify-between text-[11px]"><span className={complete ? "text-[#1DB954]" : "text-amber-300"}>{track.metadata_completion}%</span><span className="text-[#666]">{complete ? "Ready" : track.missing_metadata?.slice(0, 2).join(", ") || "Incomplete"}</span></div><div className="h-1.5 overflow-hidden rounded-full bg-[#292929]"><div className={`h-full rounded-full ${complete ? "bg-[#1DB954]" : "bg-amber-400"}`} style={{ width: `${track.metadata_completion}%` }} /></div></div><div className="flex justify-end gap-1"><button disabled={readOnly || index === 0} onClick={(event) => { event.stopPropagation(); onMove(track.id, -1); }} className="flex h-9 w-9 items-center justify-center rounded-lg text-[#777] hover:bg-[#2a2a2a] hover:text-white disabled:opacity-20"><ArrowUp className="h-4 w-4" /></button><button disabled={readOnly || index === release.tracks.length - 1} onClick={(event) => { event.stopPropagation(); onMove(track.id, 1); }} className="flex h-9 w-9 items-center justify-center rounded-lg text-[#777] hover:bg-[#2a2a2a] hover:text-white disabled:opacity-20"><ArrowDown className="h-4 w-4" /></button><button onClick={(event) => { event.stopPropagation(); onEdit(track); }} className="flex h-9 w-9 items-center justify-center rounded-lg text-[#aaa] hover:bg-[#2a2a2a] hover:text-white"><Settings2 className="h-4 w-4" /></button>{!readOnly && <button onClick={(event) => { event.stopPropagation(); onRemove(track.id); }} className="flex h-9 w-9 items-center justify-center rounded-lg text-[#777] hover:bg-red-500/10 hover:text-red-300"><Trash2 className="h-4 w-4" /></button>}</div></article>; })}</div>{!release.tracks.length && <div className="flex min-h-48 flex-col items-center justify-center px-6 text-center"><Disc3 className="h-10 w-10 text-[#555]" /><p className="mt-3 font-black text-white">ترکی به انتشار اضافه نشده است</p><p className="mt-1 text-sm text-[#707070]">فایل‌های جدید را بارگذاری کنید یا از Recordings انتخاب کنید.</p></div>}</div>;

const TaxonomySelector: React.FC<{ label: string; items: TaxonomyOption[]; value: number[]; onChange: (value: number[]) => void; disabled?: boolean }> = ({ label, items, value, onChange, disabled }) => <div><label className={labelClass}>{label}</label><div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto rounded-xl border border-[#303030] bg-[#181818] p-3">{items.map((item) => { const active = value.includes(item.id); return <button disabled={disabled} type="button" key={item.id} onClick={() => onChange(active ? value.filter((id) => id !== item.id) : [...value, item.id])} className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${active ? "bg-[#1DB954] text-black" : "bg-[#252525] text-[#aaa] hover:text-white"}`}>{item.title || item.name}</button>; })}</div></div>;

const ChoiceChips: React.FC<{ label: string; options: string[]; value: string[]; onChange: (value: string[]) => void; disabled?: boolean }> = ({ label, options, value, onChange, disabled }) => <div><label className={labelClass}>{label}</label><div className="flex flex-wrap gap-2 rounded-xl border border-[#303030] bg-[#181818] p-3">{options.map((option) => { const active = value.includes(option); return <button disabled={disabled} key={option} type="button" onClick={() => onChange(active ? value.filter((item) => item !== option) : [...value, option])} className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${active ? "bg-[#1DB954] text-black" : "bg-[#252525] text-[#aaa]"}`} dir="ltr">{option}</button>; })}</div></div>;

const SplitEditor: React.FC<{ value: Array<{ name: string; share: number | string }>; onChange: (value: Array<{ name: string; share: number | string }>) => void; readOnly?: boolean }> = ({ value, onChange, readOnly }) => {
  const total = value.reduce((sum, item) => sum + (Number(item.share) || 0), 0);
  return <div><div className="mb-2 flex items-center justify-between"><label className="text-xs font-black text-[#d7d7d7]">سهم ترانه‌سرایان</label><span className={`text-xs font-black ${Math.abs(total - 100) < 0.01 ? "text-[#1DB954]" : "text-amber-300"}`}>{total}%</span></div><div className="space-y-2">{value.map((split, index) => <div key={index} className="grid grid-cols-[1fr_90px_36px] gap-2"><input disabled={readOnly} className={inputClass} value={split.name} onChange={(event) => onChange(value.map((item, position) => position === index ? { ...item, name: event.target.value } : item))} placeholder="نام" /><input disabled={readOnly} type="number" min={0} max={100} className={inputClass} value={split.share} onChange={(event) => onChange(value.map((item, position) => position === index ? { ...item, share: event.target.value } : item))} /><button disabled={readOnly} onClick={() => onChange(value.filter((_, position) => position !== index))} className="flex items-center justify-center rounded-xl bg-[#252525] text-[#777] hover:text-red-300"><X className="h-4 w-4" /></button></div>)}</div>{!readOnly && <button onClick={() => onChange([...value, { name: "", share: 0 }])} className="mt-2 inline-flex items-center gap-1 text-xs font-black text-[#1DB954]"><Plus className="h-3.5 w-3.5" />افزودن سهم</button>}</div>;
};

export default ReleaseComposer;
