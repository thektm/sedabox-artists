import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  Clock3,
  CopyPlus,
  Disc3,
  FileEdit,
  Loader2,
  Music2,
  Plus,
  RefreshCw,
  Search,
  Send,
  Trash2,
} from "lucide-react";
import { apiRequest, getApiErrorMessage } from "../lib/api";
import { useNavigation } from "../contexts/NavigationContext";
import { useToast } from "../contexts/ToastContext";
import ConfirmModal from "./ConfirmModal";
import { ArtistRelease, ReleaseContributor, ReleaseStatus, ReleaseType } from "./releaseTypes";

interface ReleasesResponse {
  results: ArtistRelease[];
  contributors: ReleaseContributor[];
}

type Tab = "all" | ReleaseStatus;

const statusMeta: Record<ReleaseStatus, { label: string; className: string; icon: React.ReactNode }> = {
  draft: { label: "پیش‌نویس", className: "bg-white/10 text-[#cfcfcf]", icon: <FileEdit className="h-3.5 w-3.5" /> },
  in_review: { label: "در حال بررسی", className: "bg-amber-500/10 text-amber-300", icon: <Clock3 className="h-3.5 w-3.5" /> },
  changes_requested: { label: "نیازمند اصلاح", className: "bg-orange-500/10 text-orange-300", icon: <AlertTriangle className="h-3.5 w-3.5" /> },
  approved: { label: "تأییدشده", className: "bg-emerald-500/10 text-emerald-300", icon: <CheckCircle2 className="h-3.5 w-3.5" /> },
  scheduled: { label: "زمان‌بندی‌شده", className: "bg-blue-500/10 text-blue-300", icon: <CalendarDays className="h-3.5 w-3.5" /> },
  live: { label: "منتشرشده", className: "bg-[#1DB954]/10 text-[#1DB954]", icon: <CheckCircle2 className="h-3.5 w-3.5" /> },
  rejected: { label: "ردشده", className: "bg-red-500/10 text-red-300", icon: <AlertTriangle className="h-3.5 w-3.5" /> },
  taken_down: { label: "حذف‌شده", className: "bg-red-500/10 text-red-300", icon: <Trash2 className="h-3.5 w-3.5" /> },
};

const typeLabel: Record<ReleaseType, string> = {
  single: "Single",
  ep: "EP",
  album: "Album",
  compilation: "Compilation",
};

const formatDate = (value?: string) => {
  if (!value) return "بدون تاریخ";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "short", day: "numeric" }).format(date);
};

const Releases: React.FC = () => {
  const { navigateTo } = useNavigation();
  const { showToast } = useToast();
  const [releases, setReleases] = useState<ArtistRelease[]>([]);
  const [tab, setTab] = useState<Tab>("all");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [cloningId, setCloningId] = useState<string | null>(null);
  const [deleteRelease, setDeleteRelease] = useState<ArtistRelease | null>(null);

  const load = useCallback(async (quiet = false) => {
    quiet ? setRefreshing(true) : setLoading(true);
    try {
      const data = await apiRequest<ReleasesResponse>("/artist/releases/");
      setReleases(Array.isArray(data.results) ? data.results : []);
      if (quiet) showToast("Releases refreshed successfully.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not load releases."), "error");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [showToast]);

  useEffect(() => { void load(); }, [load]);

  const openRelease = (release: ArtistRelease) => {
    if (!release.legacy) return navigateTo("release-composer", { id: release.id });
    if (release.legacy_kind === "song" && release.song_id) return navigateTo("details", { type: "song", id: release.song_id });
    if (release.album_id) return navigateTo("details", { type: "album", id: release.album_id });
  };

  const createRelease = async () => {
    setCreating(true);
    try {
      const release = await apiRequest<ArtistRelease>("/artist/releases/", {
        method: "POST",
        body: { title: "Untitled Release", release_type: "album" },
      });
      navigateTo("release-composer", { id: release.id });
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not create a release draft."), "error");
    } finally {
      setCreating(false);
    }
  };

  const cloneRelease = async (source: ArtistRelease) => {
    if (source.legacy || cloningId) return;
    setCloningId(source.id);
    try {
      const release = await apiRequest<ArtistRelease>(`/artist/releases/${source.id}/clone/`, {
        method: "POST",
        body: { mode: source.status === "rejected" || source.status === "changes_requested" ? "revision" : "duplicate" },
      });
      showToast("An editable release copy was created. Live recordings were not changed.", "success");
      navigateTo("release-composer", { id: release.id });
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not create an editable release copy."), "error");
    } finally {
      setCloningId(null);
    }
  };

  const removeDraft = async () => {
    if (!deleteRelease) return;
    try {
      await apiRequest(`/artist/releases/${deleteRelease.id}/`, { method: "DELETE", body: { lock_version: deleteRelease.lock_version } });
      setReleases((current) => current.filter((item) => item.id !== deleteRelease.id));
      setDeleteRelease(null);
      showToast("Release draft removed. Its recordings were kept.", "success");
    } catch (error) {
      showToast(getApiErrorMessage(error, "Could not remove the release draft."), "error");
    }
  };

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return releases.filter((release) => {
      const tabMatch = tab === "all" || release.status === tab;
      const text = [release.title, release.title_en, release.release_type, release.primary_artist?.name, release.primary_artist?.name_en]
        .filter(Boolean).join(" ").toLowerCase();
      return tabMatch && (!needle || text.includes(needle));
    });
  }, [query, releases, tab]);

  const counts = useMemo(() => releases.reduce<Record<string, number>>((acc, item) => {
    acc[item.status] = (acc[item.status] || 0) + 1;
    return acc;
  }, {}), [releases]);

  const tabs: Array<{ value: Tab; label: string }> = [
    { value: "all", label: "همه" },
    { value: "draft", label: "پیش‌نویس" },
    { value: "in_review", label: "در حال بررسی" },
    { value: "changes_requested", label: "نیازمند اصلاح" },
    { value: "approved", label: "تأییدشده" },
    { value: "scheduled", label: "زمان‌بندی‌شده" },
    { value: "live", label: "منتشرشده" },
    { value: "rejected", label: "ردشده" },
    { value: "taken_down", label: "حذف‌شده" },
  ];

  return (
    <div className="min-h-full w-full p-4 sm:p-6 lg:p-8" dir="rtl">
      <header className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-[#1DB954]">Music workspace</p>
          <h1 className="text-3xl font-black text-white lg:text-4xl">انتشارها</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-[#929292]">آلبوم، EP، تک‌آهنگ و کامپلیشن را از یک مسیر واحد بسازید؛ همه‌چیز تا زمان ارسال نهایی به‌صورت پیش‌نویس خصوصی ذخیره می‌شود.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => void load(true)} disabled={loading || refreshing} className="flex h-11 w-11 items-center justify-center rounded-xl border border-[#343434] bg-[#181818] text-white transition hover:bg-[#242424] disabled:opacity-40" title="Refresh">
            <RefreshCw className={`h-5 w-5 ${refreshing ? "animate-spin" : ""}`} />
          </button>
          <button onClick={() => void createRelease()} disabled={creating} className="inline-flex min-w-44 items-center justify-center gap-2 rounded-xl bg-[#1DB954] px-5 py-3 font-black text-black transition hover:bg-[#1ed760] disabled:opacity-50">
            {creating ? <Loader2 className="h-5 w-5 animate-spin" /> : <Plus className="h-5 w-5" />}
            ساخت انتشار
          </button>
        </div>
      </header>

      <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "پیش‌نویس فعال", value: counts.draft || 0, icon: <FileEdit className="h-5 w-5" /> },
          { label: "در حال بررسی", value: counts.in_review || 0, icon: <Send className="h-5 w-5" /> },
          { label: "زمان‌بندی‌شده", value: counts.scheduled || 0, icon: <CalendarDays className="h-5 w-5" /> },
          { label: "منتشرشده", value: counts.live || 0, icon: <CheckCircle2 className="h-5 w-5" /> },
        ].map((item) => <div key={item.label} className="flex items-center gap-3 border-b border-[#2a2a2a] bg-[#171717] px-4 py-4 sm:rounded-xl sm:border">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#242424] text-[#1DB954]">{item.icon}</span>
          <div><p className="text-2xl font-black text-white">{item.value}</p><p className="text-xs text-[#777]">{item.label}</p></div>
        </div>)}
      </div>

      <div className="mb-5 flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex gap-1 overflow-x-auto rounded-xl bg-[#171717] p-1">
          {tabs.map((item) => <button key={item.value} onClick={() => setTab(item.value)} className={`shrink-0 rounded-lg px-4 py-2 text-xs font-bold transition sm:text-sm ${tab === item.value ? "bg-white text-black" : "text-[#999] hover:bg-[#252525] hover:text-white"}`}>{item.label}</button>)}
        </div>
        <div className="relative w-full xl:w-80">
          <Search className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-[#666]" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} className="w-full rounded-xl border border-[#333] bg-[#171717] py-3 pr-11 pl-4 text-white outline-none placeholder:text-[#666] focus:border-[#1DB954]" placeholder="جستجو در انتشارها" />
        </div>
      </div>

      {loading ? <div className="space-y-2">{Array.from({ length: 6 }).map((_, index) => <div key={index} className="h-24 animate-pulse rounded-xl bg-[#181818]" />)}</div> : filtered.length ? (
        <div className="overflow-hidden rounded-2xl border border-[#282828] bg-[#151515]">
          <div className="hidden grid-cols-[minmax(280px,1fr)_110px_120px_150px_170px] gap-4 border-b border-[#282828] px-5 py-3 text-xs font-bold text-[#707070] lg:grid">
            <span>انتشار</span><span>نوع</span><span>ترک‌ها</span><span>وضعیت</span><span className="text-left">عملیات</span>
          </div>
          <div className="divide-y divide-[#282828]">
            {filtered.map((release) => {
              const meta = statusMeta[release.status] || statusMeta.draft;
              const artwork = release.release_metadata?.cover_url;
              return <article key={release.id} onClick={() => openRelease(release)} className="grid cursor-pointer gap-4 p-4 transition hover:bg-[#1d1d1d] lg:grid-cols-[minmax(280px,1fr)_110px_120px_150px_170px] lg:items-center lg:px-5">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-[#262626]">{artwork ? <img src={artwork} alt="" className="h-full w-full object-cover" /> : <Disc3 className="h-7 w-7 text-[#666]" />}</div>
                  <div className="min-w-0"><p className="truncate text-base font-black text-white">{release.title || "Untitled Release"}</p>{release.title_en && <p className="truncate text-xs text-[#777]" dir="ltr">{release.title_en}</p>}<p className="mt-1 text-xs text-[#6d6d6d]">آخرین تغییر: {formatDate(release.updated_at)}</p></div>
                </div>
                <p className="text-sm font-bold text-[#b7b7b7]"><span className="ml-1 text-xs font-normal text-[#666] lg:hidden">نوع:</span>{typeLabel[release.release_type] || release.release_type}</p>
                <p className="text-sm font-bold text-white"><span className="ml-1 text-xs font-normal text-[#666] lg:hidden">ترک‌ها:</span>{release.tracks?.length || release.track_ids?.length || 0}</p>
                <span className={`inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold ${meta.className}`}>{meta.icon}{meta.label}</span>
                <div className="flex justify-end gap-1">
                  {!release.legacy && release.status !== "draft" && <button disabled={Boolean(cloningId)} onClick={(event) => { event.stopPropagation(); void cloneRelease(release); }} className="flex h-10 w-10 items-center justify-center rounded-lg text-[#888] transition hover:bg-[#1DB954]/10 hover:text-[#1DB954] disabled:opacity-40" title="Create editable copy">{cloningId === release.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CopyPlus className="h-4 w-4" />}</button>}
                  {!release.legacy && release.status === "draft" && <button onClick={(event) => { event.stopPropagation(); setDeleteRelease(release); }} className="flex h-10 w-10 items-center justify-center rounded-lg text-[#888] transition hover:bg-red-500/10 hover:text-red-300" title="Remove draft"><Trash2 className="h-4 w-4" /></button>}
                  <button className="flex h-10 min-w-10 items-center justify-center rounded-lg bg-[#242424] px-3 text-xs font-bold text-white transition hover:bg-[#303030]">{release.legacy ? "مشاهده" : release.status === "draft" ? "ادامه" : "جزئیات"}</button>
                </div>
              </article>;
            })}
          </div>
        </div>
      ) : (
        <div className="flex min-h-72 flex-col items-center justify-center rounded-2xl border border-dashed border-[#303030] bg-[#151515] px-6 text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#242424]"><Music2 className="h-8 w-8 text-[#777]" /></div>
          <h2 className="text-xl font-black text-white">انتشاری پیدا نشد</h2>
          <p className="mt-2 max-w-md text-sm leading-6 text-[#777]">{query ? "عبارت جستجو یا فیلتر را تغییر دهید." : "اولین انتشار خود را بسازید و همه ترک‌ها را همان‌جا اضافه کنید."}</p>
          {!query && <button onClick={() => void createRelease()} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#1DB954] px-5 py-2.5 font-black text-black"><Plus className="h-5 w-5" />ساخت انتشار</button>}
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteRelease)}
        title="حذف پیش‌نویس انتشار"
        description="پیش‌نویس حذف می‌شود، اما فایل‌های صوتی بارگذاری‌شده در بخش Recordings به‌صورت خصوصی باقی می‌مانند."
        confirmLabel="حذف پیش‌نویس"
        cancelLabel="انصراف"
        onCancel={() => setDeleteRelease(null)}
        onConfirm={() => void removeDraft()}
      />
    </div>
  );
};

export default Releases;
